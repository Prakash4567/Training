package dxc.LeaveManagementProject;

public enum LeaveStatus {

	PENDING, APPROVED, REJECTED
}
