package dxc.LeaveManagementProject;

public enum LeaveType {
	EL, PL, ML
}
