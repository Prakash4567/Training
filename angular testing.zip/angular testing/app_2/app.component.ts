import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular Testing';
  company = "Dxc";
  trainer = "Prasanna";

  v1=12.5;
  v2=11.4;

  arr1={a:12,b:13};
  arr2={a:12,b:13};


  msg="Prasanna taking Angular Training";

  Stud = ["Shrisom", "Eldo", "Himanshu"];

  status=null;
  city="Chennai";


  a1 = {
    name: "Garima"
  };

  getStatus() : boolean {
    return true;
  }

}
