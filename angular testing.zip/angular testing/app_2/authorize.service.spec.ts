import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AuthorizeService } from './authorize.service';

describe('AuthorizeService', () => {
  const responseForm = '<form />';
  
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [AuthorizeService]
  }));

  it('should be called with proper arguments', () => {
    const auth0Service = TestBed.get(AuthorizeService);
    const http = TestBed.get(HttpTestingController);
    let loginResponse;

    auth0Service.login('blacksonic', 'secret').subscribe((response) => {
      loginResponse = response;
    });

    http.expectOne({
      url: 'https://blacksonic.eu.auth0.com.auth0.com/usernamepassword/login',
      method: 'POST'
    }).flush(responseForm);
    expect(loginResponse).toEqual(responseForm);
  });

  it('should be created', () => {
    const service: AuthorizeService = TestBed.get(AuthorizeService);
    expect(service).toBeTruthy();
  });

});
