import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { GithubService } from './github.service';
import { Blog } from './blog';

describe('Blog Entry Domain Class', () => {
  let blog : Blog;

  beforeEach(() => {
    blog = new Blog('Jasmine Testing', 'Service Testing', 'Mocking to be Done', 1);
  });

  it('should be createable by constructor', () => {
    expect(blog.title).toBe('Jasmine Testing');
    expect(blog.contentRendered).toBe('Service Testing');
    expect(blog.contentMarkdown).toBe('Mocking to be Done');
    expect(blog.id).toBe(1);
  });
});

describe('GithubService', () => {
  const profileInfo = {
    login: 'PrasannaTrainer',
    id: 35065215,
    name: 'User'
  };

  const madhuraInfo = {
    login: 'madhura-dxc',
    id: 68767848,
    name: 'User',
    site_admin : false
  };

  const employProfile = {
    empId:3000,
    empName:"ANKITA",
    empEmail:"ANKITA2@HEXAWARE.COM",
    empMobile:"8825792015",
    empDptName:"BI",
    empDateOfJoin:"2017-11-14",
    empMgrId:2000,
    empLeaveBalance:3
  };

  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
      providers: [GithubService]
  }));

  it('should be created', () => {
    const service: GithubService = TestBed.get(GithubService);
    expect(service).toBeTruthy();
  });

  it('should get profile data of Madhura', () => {
    const githubService = TestBed.get(GithubService);
    const http = TestBed.get(HttpTestingController);
    let profileResponse;

    githubService.getProfile('madhura-dxc').subscribe((response) => {
      profileResponse = response;
    });

    http.expectOne('https://api.github.com/users/madhura-dxc').flush(madhuraInfo);
    expect(profileResponse).toEqual(madhuraInfo);
  });

  it('should get profile data of user', () => {
    const githubService = TestBed.get(GithubService);
    const http = TestBed.get(HttpTestingController);
    let profileResponse;

    githubService.getProfile('PrasannaTrainer').subscribe((response) => {
      profileResponse = response;
    });

    http.expectOne('https://api.github.com/users/PrasannaTrainer').flush(profileInfo);
    expect(profileResponse).toEqual(profileInfo);
  });

  it('should get profile of LMS Employee', () => {
    const githubService = TestBed.get(GithubService);
    const http = TestBed.get(HttpTestingController);
    let profileResponse;

    githubService.getEmployProfile(3000).subscribe((response) => {
      profileResponse = response;
    });

    http.expectOne('http://localhost:8080/LeaveManagementProject/webapi/employee/searchemployee/3000').flush(profileInfo);
    expect(profileResponse).toEqual(profileInfo);
  });
});
