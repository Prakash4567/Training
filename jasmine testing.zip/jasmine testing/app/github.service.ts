import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GithubService {

  constructor(private _http : HttpClient) { }

  getEmployProfile(empno : number) {
    return this._http
      .get('http://localhost:8080/LeaveManagementProject/webapi/employee/searchemployee/'+empno);
  }
  getProfile(userName: string) {
    return this._http
      .get(`https://api.github.com/users/${userName}`);
  }
}
