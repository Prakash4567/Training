export class Blog {

    id: number;
    title: string;
    contentRendered: string;
    contentMarkdown: string;

    constructor(title: string, contentRendered: string, contentMarkdown: string, id: number) {
        this.title = title;
        this.contentRendered = contentRendered;
        this.contentMarkdown = contentMarkdown;
        if (id) {
          this.id = id;
        }
      }    
}
