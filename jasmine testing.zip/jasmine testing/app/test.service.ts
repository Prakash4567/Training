import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  getName() {
    return "Prasanna";
  }
  getTopic() {
    return "Angular 8";
  }
  constructor() { }
}
