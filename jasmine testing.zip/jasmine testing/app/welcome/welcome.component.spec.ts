import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By }                                from '@angular/platform-browser';

import { WelcomeComponent } from './welcome.component';
import { UserService } from '../user.service';
import { DebugElement } from '@angular/core';

describe('WelcomeComponent', () => {
  let component: WelcomeComponent;
  let fixture: ComponentFixture<WelcomeComponent>;

  let componentUserService: UserService; // the actually injected service
  let userService: UserService; // the TestBed injected service
  let el: HTMLElement; // the DOM element with the welcome message
  let de: DebugElement;  // the DebugElement with the welcome message

  let userServiceStub: {
    isLoggedIn: boolean;
    user: { name: string}
  };

  beforeEach(async(() => {
    userServiceStub = {
      isLoggedIn: true,
      user: { name: 'Sanil'}
    };

    TestBed.configureTestingModule({
      declarations: [ WelcomeComponent ],
      providers:    [ {provide: UserService, useValue: userServiceStub } ]

    })
    .compileComponents();
     //  get the "welcome" element by CSS selector (e.g., by class name)
 
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WelcomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create Welcome Component', () => {
    expect(component).toBeTruthy();
  });

  it('should request login if not logged in', () => {
    // userService = TestBed.get(UserService);
    userService = fixture.debugElement.injector.get(UserService);

    userService.isLoggedIn = false; // welcome message hasn't been shown yet
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.welcome'));
    el = de.nativeElement;

    const content = el.textContent;
    // expect(content).not.toContain('Welcome', 'not welcomed');
    expect(content).toMatch(/Welcome/, "Welcome");
  });

  it('TestBed and Component UserService should be the same', () => {
    userService = fixture.debugElement.injector.get(UserService);
    componentUserService = userService;
    // UserService from the root injector
    userService = TestBed.get(UserService);

    expect(userService === componentUserService).toBe(true);
  });

  it('stub object and injected UserService should not be the same', () => {
    expect(userServiceStub === userService).toBe(false);

    // Changing the stub object has no effect on the injected service
    userServiceStub.isLoggedIn = false;
    expect(userService.isLoggedIn).toBe(true);
  });


  it('should welcome the user', () => {
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.welcome'));
    el = de.nativeElement;

    const content = el.textContent;
    expect(content).toContain('Welcome', '"Welcome ..."');
    expect(content).toContain('Sanil', 'expected name');
  });

  it('should welcome "Sanil"', () => {
    // de = fixture.debugElement.query(By.css('.welcome'));
    // el = de.nativeElement;
    userService = fixture.debugElement.injector.get(UserService);
    componentUserService = userService;
    // UserService from the root injector
    userService = TestBed.get(UserService);

    //  get the "welcome" element by CSS selector (e.g., by class name)
    de = fixture.debugElement.query(By.css('.welcome'));
    el = de.nativeElement;

    userService.user.name = 'Sanil'; // welcome message hasn't been shown yet
    fixture.detectChanges();
    expect(el.textContent).toContain('Sanil');
  });

});
