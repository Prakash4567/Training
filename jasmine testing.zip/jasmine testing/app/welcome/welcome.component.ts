import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  welcome = '-- not initialized yet --';
  constructor(private userSerivce : UserService) { }

  ngOnInit() {
    this.welcome = this.userSerivce.isLoggedIn ?
      'Welcome, ' + this.userSerivce.user.name :
      'Please log in.';
  }

}
