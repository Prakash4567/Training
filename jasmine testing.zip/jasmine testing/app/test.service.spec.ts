import { TestBed } from '@angular/core/testing';

import { TestService } from './test.service';

describe('TestService', () => {
  let obj=new TestService();
  beforeEach(() => TestBed.configureTestingModule({
    providers: [TestService]
  }));

  it('should be created', () => {
    const service: TestService = TestBed.get(TestService);
    expect(service).toBeTruthy();
  });
  it('should getName() return Prasanna', () => {
    expect(obj.getName()).toEqual("Prasanna");
  });
  it('should getToipic() return Angular 8', () => {
    expect(obj.getTopic()).toEqual("Angular 8");
  });


});
