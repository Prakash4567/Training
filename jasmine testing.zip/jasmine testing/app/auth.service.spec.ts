import { TestBed } from '@angular/core/testing';

import { AuthService } from './auth.service';

describe('AuthService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('Author Service should be created', () => {
    const service: AuthService = TestBed.get(AuthService);
    expect(service).toBeTruthy();
  });
  it('Author Service getName() returns Dxc', () => {
    const service: AuthService = TestBed.get(AuthService);
    expect(service.getName()).toEqual("Dxc");
  });

});
