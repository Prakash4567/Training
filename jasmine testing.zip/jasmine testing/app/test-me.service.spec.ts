import { TestBed } from '@angular/core/testing';

import { TestMeService } from './test-me.service';
import { TestService } from './test.service';

describe('TestMeService', () => {
  let obj: TestMeService;

  beforeEach(() => { TestBed.configureTestingModule({
    providers: [TestMeService,TestService]
  });
  spyOn(TestService.prototype, 'getName').and.returnValue("Prakash");
  spyOn(TestService.prototype, 'getTopic').and.returnValue('Angular 9');

  obj=TestBed.get(TestMeService);

  });

  it('should be created', () => {
    const service: TestMeService = TestBed.get(TestMeService);
    expect(service).toBeTruthy();
  });

  it('Should Display (Testing showInfo())',() => {
    expect(obj.showInfo()).toEqual("Name is Prakash Taking Angular 9");
  });

});
