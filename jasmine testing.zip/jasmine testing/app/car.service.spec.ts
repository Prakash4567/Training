import { TestBed } from '@angular/core/testing';

import { CarService } from './car.service';
import { EngineService } from './engine.service';

describe('CarService', () => {
  let subject: CarService;
  
  beforeEach(() => { TestBed.configureTestingModule({
    providers: [EngineService, CarService]
  })
  subject = TestBed.get(CarService)
});
  it('should be created', () => {
    const service: CarService = TestBed.get(CarService);
    expect(service).toBeTruthy();
  });
  it('should display name with engine', () => {
    expect(subject.getName()).toEqual('Car with Basic engine(150 HP)');
  });
});

describe('CarMock', () => {
  let subject: CarService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EngineService, CarService]
    });
    spyOn(EngineService.prototype, 'getHorsepower').and.returnValue(400);
    spyOn(EngineService.prototype, 'getName').and.returnValue('V8 engine');
    subject = TestBed.get(CarService);
  });

  it('should display name with engine', () => {
    expect(subject.getName()).toEqual('Car with V8 engine(400 HP)');
  });

});