import { Injectable } from '@angular/core';
import { TestService } from './test.service';

@Injectable({
  providedIn: 'root'
})
export class TestMeService {

  showInfo() {
    return "Name is "+this.test.getName() + " Taking " +this.test.getTopic();
  }
 

  constructor(private test : TestService) { }
}
